
<form action="{{ route('service.update', $service->id) }}" method="POST" enctype="multipart/form-data">
    @csrf
    @method("PUT")

    <div class="row">
        {{-- Service Name --}}
        <div class="col-sm-12">
            <div class="form-group">
                <label for="service_name">Service Name <span class="text-danger">*</span></label>
                <input type="text" class="form-control custom-input" id="service_name" name="service_name"
                    value="{{ old('service_name', $service->service_name) }}" placeholder="Service Name" required>
                @error('service_name') <span class="text-danger">{{ $message }}</span>
                @enderror
            </div>
        </div>

        {{-- Service Details --}}
        <div class="col-sm-8">
            <div class="form-group">
                <label for="service_details">Service Details <span class="text-danger">*</span></label>
                <textarea class="form-control summernote" id="service_details" name="service_details" rows="5"
                    placeholder="Write Here" required>{{ old('service_details', $service->service_details) }}</textarea>
                @error('service_details') <span class="text-danger">{{ $message }}</span>
                @enderror
            </div>
        </div>

        {{-- Image --}}
        <div class="col-sm-4 image">
            <div class="form-group">
                <label for="edit_image" class="form-label">Image<span class="text-danger">*</span></label>
                <input type="file" class="form-control mb-3 edit_image" name="image"  accept="image/*">
                @if($service->image)
                <img class="edit_image_preview mt-2" src="{{ asset('storage/' . $service->image) }}" alt="Old Image" width="96"
                    height="72">
                @endif
                @error('image') <span class="text-danger">{{ $message }}</span>
                @enderror
            </div>
        </div>



        <div class="col-sm-12">
            <div class="row">
                {{-- Service Keypoints --}}
                <div class="col-sm">
                    <h2 class="">Service Keypoints </h2>
                    <hr>
                </div>

                <div class="col-sm-12">
                    <div class="form-group">
                        <label>Service Keypoint 1 </label>
                        <input type="text" class="form-control custom-input" name="service_keypoint_1"
                            value="{{ old('service_keypoint_1', $service->service_keypoint_1) }}">
                        @error('service_keypoint_1') <span class="text-danger">{{ $message }}</span> @enderror
                    </div>
                </div>

                <div class="col-sm-12">
                    <div class="form-group">
                        <label>Service Keypoint 2 </label>
                        <input type="text" class="form-control custom-input" name="service_keypoint_2"
                            value="{{ old('service_keypoint_2', $service->service_keypoint_2) }}">
                        @error('service_keypoint_2') <span class="text-danger">{{ $message }}</span> @enderror
                    </div>
                </div>

                <div class="col-sm-12">
                    <div class="form-group">
                        <label>Service Keypoint 3 </label>
                        <input type="text" class="form-control custom-input" name="service_keypoint_3"
                            value="{{ old('service_keypoint_3', $service->service_keypoint_3) }}">
                        @error('service_keypoint_3') <span class="text-danger">{{ $message }}</span> @enderror
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal-footer border-0">
        <div class="modal-button-box">
            <button type="button" class="cancel-button-1" data-bs-dismiss="modal">
                <i class='bx bx-x bx-flashing'></i> Cancel
            </button>
            <button type="submit" class="submit-button-1">
                <i class='bx bx-upload bx-flashing'></i> Update
            </button>
        </div>

    </div>
</form>






<!---------------------------  old code  ----------------------------------->

<!-- <form action="{{ route('service.update', $service->id) }}" method="POST" enctype="multipart/form-data">
    @csrf
    @method("PUT")

    <div class="row">
        {{-- Service Name --}}
        <div class="col-sm-12">
            <div class="form-group">
                <label for="service_name">Service Name <span class="text-danger">*</span></label>
                <input type="text" class="form-control custom-input" id="service_name" name="service_name"
                    value="{{ old('service_name', $service->service_name) }}" placeholder="Service Name" required>
                @error('service_name') <span class="text-danger">{{ $message }}</span>
                @enderror
            </div>
        </div>

        {{-- Service Details --}}
        <div class="col-sm-8">
            <div class="form-group">
                <label for="service_details">Service Details <span class="text-danger">*</span></label>
                <textarea class="form-control summernote" id="service_details" name="service_details" rows="5"
                    placeholder="Write Here" required>{{ old('service_details', $service->service_details) }}</textarea>
                @error('service_details') <span class="text-danger">{{ $message }}</span>
                @enderror
            </div>
        </div>

        {{-- Image --}}
        <div class="col-sm-4 image">
            <div class="form-group">
                <label for="edit_image" class="form-label">Image<span class="text-danger">*</span></label>
                <input type="file" class="form-control mb-3 edit_image" name="image"  accept="image/*">
                @if($service->image)
                <img class="edit_image_preview mt-2" src="{{ asset('storage/' . $service->image) }}" alt="Old Image" width="96"
                    height="72">
                @endif
                @error('image') <span class="text-danger">{{ $message }}</span>
                @enderror
            </div>
        </div>
        <div class="col-sm-6">
            <div class="row">
                {{-- Counter --}}
                <div class="col-sm-12">
                    <h2 class="">Counter</h2>
                    <hr>
                </div>

                <div class="col-sm-12">
                    <div class="form-group">
                        <label>Counter Title</label>
                        <input type="text" class="form-control custom-input" name="counter_title"
                            value="{{ old('counter_title', $service->counter_title) }}">
                        @error('counter_title') <span class="text-danger">{{ $message }}</span> @enderror
                    </div>
                </div>

                <div class="col-sm-6">
                    <div class="form-group">
                        <label>Data Count</label>
                        <input type="number" class="form-control custom-input" name="data_count" min="0"
                            value="{{ old('data_count', $service->data_count) }}">
                        @error('data_count') <span class="text-danger">{{ $message }}</span> @enderror
                    </div>
                </div>

                <div class="col-sm-6">
                    <div class="form-group">
                        <label>Counter Symbol</label>
                        <input type="text" class="form-control custom-input" name="counter_symbol"
                            value="{{ old('counter_symbol', $service->counter_symbol) }}">
                        @error('counter_symbol') <span class="text-danger">{{ $message }}</span> @enderror
                    </div>
                </div>

                {{-- Counter Icon --}}
                <div class="col-sm-12 image">
                    <div class="form-group">
                        <label class="form-label">Icon</label>
                        <input type="file" class="form-control mb-3 edit_image" name="counter_icon" accept="image/*">
                        @if($service->counter_icon)
                        <img class="mt-2 edit_image_preview" src="{{ asset('storage/' . $service->counter_icon) }}" alt="Old Icon"
                            width="96" height="72">
                        @endif
                        @error('counter_icon') <span class="text-danger">{{ $message }}</span> @enderror
                    </div>
                </div>
            </div>
        </div>
        {{-- Contact --}}
        <div class="col-sm-6">
            <div class="row">
                <div class="col-sm-12">
                    <h2>Contact</h2>
                    <hr>
                </div>

                <div class="col-sm-12">
                    <div class="form-group">
                        <label>Title</label>
                        <input type="text" class="form-control custom-input" name="contact_title"
                            value="{{ old('contact_title', $service->contact_title) }}">
                        @error('contact_title') <span class="text-danger">{{ $message }}</span> @enderror
                    </div>
                </div>

                <div class="col-sm-6">
                    <div class="form-group">
                        <label>Button Text</label>
                        <input type="text" class="form-control custom-input" name="button_text"
                            value="{{ old('button_text', $service->button_text) }}">
                        @error('button_text') <span class="text-danger">{{ $message }}</span> @enderror
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label>Button url</label>
                        <input type="url" class="form-control custom-input" name="contact_url"
                            value="{{ old('contact_url', $service->contact_url) }}">
                        @error('contact_url') <span class="text-danger">{{ $message }}</span> @enderror
                    </div>
                </div>
            </div>
        </div>




    </div>

    <div class="modal-footer border-0">
        <div class="modal-button-box">
            <button type="button" class="cancel-button-1" data-bs-dismiss="modal">
                <i class='bx bx-x bx-flashing'></i> Cancel
            </button>
            <button type="submit" class="submit-button-1">
                <i class='bx bx-upload bx-flashing'></i> Update
            </button>
        </div>

    </div>
</form> -->
