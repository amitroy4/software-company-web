<form action="{{ route('service-faq.update', $service->id) }}" method="POST" enctype="multipart/form-data">
    @csrf
    @method("PUT")

    <div class="mt-4" id="faq-entries">
        @foreach($service->faqs as $index => $faq)
        <div class="row faq-entry mb-3" id="faq-entry-existing-{{ $faq->id }}">
            <h5 class="text-info">Edit Key Point {{ $index + 1 }}</h5>
            <div class="col-md-12 mb-3">
                <input type="hidden" name="faq_ids[]" value="{{ $faq->id }}">
                <label class="form-label" for="question_{{ $faq->id }}">Question<span class="text-danger">
                    *</span></label>
                <input class="form-control" type="text" value="{{ $faq->question }}" name="questions[]"
                    id="question_{{ $faq->id }}" required>
            </div>
            <div class="col-md-12 mb-3">
                <label class="form-label" for="answer_{{ $faq->id }}">Answer<span class="text-danger">
                    *</span></label>
                <textarea class="form-control" name="answers[]" id="answer_{{ $faq->id }}" cols="5"
                    rows="5" required>{{ $faq->answer }}</textarea>
            </div>
            <div class="col-md-12">
                <button type="button" class="btn btn-danger btn-sm"
                    onclick="removeExistingKeypoint({{ $faq->id }})">
                    <i class="fa fa-trash"></i> Remove
                </button>
            </div>
        </div>
        @endforeach
    </div>
    <div class="d-flex align-items-center ">
        <a href="javascript:void(0)" class="btn btn-info btn-round ms-auto" onclick="addFaq()">
            <i class="fa fa-plus"></i>
            Add Faqs
        </a>
    </div>
    <div class="modal-footer border-0">
        <div class="modal-button-box">
            <button type="button" class="cancel-button-1" data-bs-dismiss="modal">
                <i class='bx bx-x bx-flashing'></i> Cancel
            </button>
            <button type="submit" class="submit-button-1">
                <i class='bx bx-upload bx-flashing'></i> Update
            </button>
        </div>

    </div>
</form>

@push('script')
<script>
    // Add new faq dynamically
   function addFaq() {
    const entryCount = document.querySelectorAll('.faq-entry').length + 1;

    const newEntry = `
        <div class="row faq-entry mb-3" id="faq-entry-${entryCount}">
            <div class="col-md-12 mb-3">
                <label class="form-label" for="question_${entryCount}">Question<span class="text-danger">
                                *</span></label>
                <input class="form-control" type="text" name="questions[]" id="question_${entryCount}" placeholder="Enter Question" required>
            </div>
            <div class="col-md-12 mb-3">
                <label class="form-label" for="answer_${entryCount}">Answer<span class="text-danger">
                                *</span></label>
                <textarea class="form-control" name="answers[]" id="answer_${entryCount}" cols="5" rows="5" placeholder="Enter Your Answer" required></textarea>
            </div>
            <div class="col-md-12">
                <button type="button" class="btn btn-danger btn-sm" onclick="removeFaqEntry('faq-entry-${entryCount}')">
                    <i class="fa fa-trash"></i> Remove
                </button>
            </div>
        </div>
    `;

    document.querySelector('#faq-entries').insertAdjacentHTML('beforeend', newEntry);
}

    // Remove newly added faqs
    function removeFaqEntry(entryId) {
        const entry = document.getElementById(entryId);
        if (entry) {
            entry.remove();
        }
    }

    // Remove existing faqs
    function removeExistingKeypoint(faqId) {
        const entry = document.getElementById(`faq-entry-existing-${faqId}`);
        if (entry) {
            entry.remove();
            // Add a hidden input to mark this faq for deletion
            const input = `<input type="hidden" name="removed_faq_ids[]" value="${faqId}">`;
            document.querySelector('#faq-entries').insertAdjacentHTML('beforeend', input);
        }
    }
</script>
@endpush
