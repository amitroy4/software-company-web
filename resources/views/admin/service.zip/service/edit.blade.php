@extends('layouts.admin')
@section('title','Service')
@section('content')
<div class="container">
    <div class="page-inner">
        <div class="row">
            <div class="col-md-12">
                <div class="card card-round">
                    <div class="card-header project-details-card-header">
                        <div class="d-flex align-items-center">
                            <h4 class="project-details-card-header-title"><i class='bx bx-edit bx-tada'></i>Edit Service
                            </h4>
                        </div>
                    </div>
                    <div class="card-body">
                        <ul class="nav nav-pills justify-content-center bg-transparent border-bottom nav-style-2 mb-3"
                            role="tablist">
                            <li class="nav-item flex-sm-fill text-sm-center" role="presentation">
                                <a class="nav-link {{ session('activeTab') == 'overview' || !session('activeTab') ? 'active' : '' }}"
                                    data-bs-toggle="tab" href="#Overview" role="tab"
                                    aria-selected="{{ session('activeTab') == 'overview' || !session('activeTab') ? 'true' : 'false' }}">
                                    Service Overview
                                </a>
                            </li>
                            <li class="nav-item flex-sm-fill text-sm-center" role="presentation">
                                <a class="nav-link {{ session('activeTab') == 'whyNeed' ? 'active' : '' }}"
                                    data-bs-toggle="tab" href="#why-need" role="tab"
                                    aria-selected="{{ session('activeTab') == 'whyNeed' ? 'true' : 'false' }}">
                                    Key Benefits
                                </a>
                            </li>
                            <li class="nav-item flex-sm-fill text-sm-center" role="presentation">
                                <a class="nav-link {{ session('activeTab') == 'offeredService' ? 'active' : '' }}"
                                    data-bs-toggle="tab" href="#offered-service" role="tab"
                                    aria-selected="{{ session('activeTab') == 'offeredService' ? 'true' : 'false' }}">
                                    Offered Service
                                </a>
                            </li>
                            <li class="nav-item flex-sm-fill text-sm-center" role="presentation">
                                <a class="nav-link {{ session('activeTab') == 'provideClient' ? 'active' : '' }}"
                                    data-bs-toggle="tab" href="#provide-client" role="tab"
                                    aria-selected="{{ session('activeTab') == 'provideClient' ? 'true' : 'false' }}">
                                    Provided Clients
                                </a>
                            </li>
                            <li class="nav-item flex-sm-fill text-sm-center" role="presentation">
                                <a class="nav-link {{ session('activeTab') == 'developmentProcess' ? 'active' : '' }}"
                                    data-bs-toggle="tab" href="#development-process" role="tab"
                                    aria-selected="{{ session('activeTab') == 'developmentProcess' ? 'true' : 'false' }}">
                                    Development Process
                                </a>
                            </li>
                            <li class="nav-item flex-sm-fill text-sm-center" role="presentation">
                                <a class="nav-link {{ session('activeTab') == 'technology' ? 'active' : '' }}"
                                    data-bs-toggle="tab" href="#Technology" role="tab"
                                    aria-selected="{{ session('activeTab') == 'technology' ? 'true' : 'false' }}">
                                    Technologies We Use
                                </a>
                            </li>
                            <li class="nav-item flex-sm-fill text-sm-center" role="presentation">
                                <a class="nav-link {{ session('activeTab') == 'faq' ? 'active' : '' }}"
                                    data-bs-toggle="tab" href="#Faq" role="tab"
                                    aria-selected="{{ session('activeTab') == 'faq' ? 'true' : 'false' }}">
                                    FAQ's
                                </a>
                            </li>
                        </ul>
                        <div class="tab-content">
                            <div class="tab-pane fade {{ session('activeTab') == 'overview' || !session('activeTab') ? 'show active' : '' }}"
                                id="Overview" role="tabpanel">
                                @include('admin.service.tab-content.service-overview')

                            </div>

                            <div class="tab-pane fade {{ session('activeTab') == 'whyNeed' ? 'show active' : '' }}"
                                id="why-need" role="tabpanel">
                                @include('admin.service.tab-content.why-need')
                            </div>
                            <div class="tab-pane fade {{ session('activeTab') == 'offeredService' ? 'show active' : '' }}"
                                id="offered-service" role="tabpanel">
                                @include('admin.service.tab-content.offered-services')
                            </div>

                        <div class="tab-pane fade {{ session('activeTab') == 'provideClient' ? 'show active' : '' }}"
                                id="provide-client" role="tabpanel">
                                @include('admin.service.tab-content.provided-client')

                            </div>

                            <div class="tab-pane fade {{ session('activeTab') == 'developmentProcess' ? 'show active' : '' }}"
                                id="development-process" role="tabpanel">
                                @include('admin.service.tab-content.developement-process')
                            </div>

                            <div class="tab-pane fade {{ session('activeTab') == 'technology' ? 'show active' : '' }}"
                                id="Technology" role="tabpanel">
                                @include('admin.service.tab-content.technologies')
                            </div>

                            <div class="tab-pane fade {{ session('activeTab') == 'faq' ? 'show active' : '' }}" id="Faq"
                                role="tabpanel">
                                @include('admin.service.tab-content.faq')
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
@endsection
